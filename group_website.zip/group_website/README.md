# Aydin Group website

Static website of the Aydin Group (Saarland University & DFKI). No build step: open `index.html` in a browser, or serve the folder with GitHub Pages.

## Structure

- `index.html` – the whole site (Home, Team, Publications, News, History & Partners, Contact). Pages are sections switched by the URL hash (`#team`, `#publications`, ...).
- `assets/research/*.svg` – illustrations for the four research areas.
- `assets/logos/*.png` – partner logos (Hereon, TUHH, EPFL, KIT).
- `tools/make_art.py` – script that generated the research illustrations (`python tools/make_art.py art.json`, needs numpy and scipy).

## Common edits

- **Add a person:** copy a `<div class="member">…</div>` block in the Team section and change the initials, name and link.
- **Add a paper:** copy a `<div class="pub">…</div>` block under the right year in the Publications section.
- **Add news:** add an `<li>` at the top of the News list.

## Publishing with GitHub Pages

Settings → Pages → Source: *Deploy from a branch* → Branch: `main`, folder `/ (root)`.
