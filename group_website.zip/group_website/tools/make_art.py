"""Generate the four research-card illustrations as inline SVG strings (640x400)."""
import json, math, sys
import numpy as np
from scipy.spatial import Delaunay, Voronoi

W, H = 640, 400
rng = np.random.default_rng(7)


def svg(body, defs=""):
    return (f'<svg viewBox="0 0 {W} {H}" preserveAspectRatio="xMidYMid slice" '
            f'xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true">'
            f'<defs>{defs}</defs>{body}</svg>')


def f(x):
    return f"{x:.1f}"


# ---------- 1. LLMs and AI agents: an agent graph around a central model ----------
def agents():
    defs = ('<linearGradient id="ga" x1="0" y1="0" x2="1" y2="1">'
            '<stop offset="0" stop-color="#132a57"/><stop offset="1" stop-color="#2d5fb3"/></linearGradient>'
            '<radialGradient id="gah" cx=".5" cy=".5" r=".5">'
            '<stop offset="0" stop-color="#9cc0ff" stop-opacity=".55"/><stop offset="1" stop-color="#9cc0ff" stop-opacity="0"/></radialGradient>')
    out = [f'<rect width="{W}" height="{H}" fill="url(#ga)"/>']
    # faint dot grid
    dots = []
    for x in range(10, W, 24):
        for y in range(10, H, 24):
            dots.append(f'<circle cx="{x}" cy="{y}" r="1.1"/>')
    out.append(f'<g fill="#ffffff" opacity=".10">{"".join(dots)}</g>')
    cx, cy = 320, 205
    sats = []
    for i in range(7):
        a = -math.pi / 2 + i * 2 * math.pi / 7 + 0.25
        sats.append((cx + 205 * math.cos(a), cy + 135 * math.sin(a)))
    edges = [(i, (i + 1) % 7) for i in range(7)] + [(0, 3), (2, 5), (1, 4)]
    lines = []
    for (x, y) in sats:
        lines.append(f'<path d="M{f(cx)} {f(cy)} Q{f((cx + x) / 2 + 18)} {f((cy + y) / 2 - 18)} {f(x)} {f(y)}"/>')
    for i, j in edges:
        (x1, y1), (x2, y2) = sats[i], sats[j]
        lines.append(f'<line x1="{f(x1)}" y1="{f(y1)}" x2="{f(x2)}" y2="{f(y2)}" stroke-dasharray="3 6"/>')
    out.append(f'<g stroke="#ffffff" stroke-opacity=".35" stroke-width="1.6" fill="none">{"".join(lines)}</g>')
    # messages travelling on hub edges
    msgs = []
    for k, (x, y) in enumerate(sats):
        t = 0.35 + 0.3 * ((k * 37) % 10) / 10
        mx = (1 - t) ** 2 * cx + 2 * (1 - t) * t * ((cx + x) / 2 + 18) + t ** 2 * x
        my = (1 - t) ** 2 * cy + 2 * (1 - t) * t * ((cy + y) / 2 - 18) + t ** 2 * y
        msgs.append(f'<circle cx="{f(mx)}" cy="{f(my)}" r="4"/>')
    out.append(f'<g fill="#bcd4ff">{"".join(msgs)}</g>')
    # hub
    out.append(f'<circle cx="{cx}" cy="{cy}" r="90" fill="url(#gah)"/>')
    out.append(f'<circle cx="{cx}" cy="{cy}" r="40" fill="#ffffff"/>')
    out.append(f'<circle cx="{cx}" cy="{cy}" r="48" fill="none" stroke="#ffffff" stroke-opacity=".5" stroke-width="2"/>')
    # hub glyph: small transformer-like stack of bars
    for r, wbar in enumerate([34, 26, 34, 20]):
        out.append(f'<rect x="{f(cx - wbar / 2)}" y="{f(cy - 17 + r * 9)}" width="{wbar}" height="5" rx="2.5" fill="#2d5fb3" opacity="{0.55 + 0.15 * (r % 2)}"/>')
    # satellites
    for k, (x, y) in enumerate(sats):
        out.append(f'<circle cx="{f(x)}" cy="{f(y)}" r="19" fill="#ffffff" fill-opacity=".95"/>')
        out.append(f'<circle cx="{f(x)}" cy="{f(y)}" r="7" fill="#2d5fb3"/>')
    # two speech bubbles
    for (x, y) in [sats[1], sats[5]]:
        bx, by = x + 22, y - 52
        bx = min(bx, W - 92)
        out.append(f'<g transform="translate({f(bx)} {f(by)})">'
                   '<rect width="78" height="36" rx="9" fill="#ffffff"/>'
                   '<path d="M10 36 L4 46 L22 36 Z" fill="#ffffff"/>'
                   '<rect x="11" y="10" width="52" height="4" rx="2" fill="#2d5fb3" opacity=".55"/>'
                   '<rect x="11" y="20" width="36" height="4" rx="2" fill="#2d5fb3" opacity=".35"/></g>')
    return svg("".join(out), defs)


# ---------- 2. Alignment and safety: reasoning chain under a magnifying lens ----------
def alignment():
    defs = ('<linearGradient id="gb" x1="0" y1="0" x2="1" y2="1">'
            '<stop offset="0" stop-color="#2a2150"/><stop offset="1" stop-color="#6a4fa6"/></linearGradient>'
            '<clipPath id="lens"><circle cx="452" cy="176" r="70"/></clipPath>')
    out = [f'<rect width="{W}" height="{H}" fill="url(#gb)"/>']
    # attention-map texture
    cells = []
    n_c, n_r = 20, 12
    cw, ch = W / n_c, H / n_r
    for i in range(n_c):
        for j in range(n_r):
            v = rng.random() ** 3
            if v > 0.05:
                cells.append(f'<rect x="{f(i * cw + 1)}" y="{f(j * ch + 1)}" width="{f(cw - 2)}" height="{f(ch - 2)}" rx="3" opacity="{v * 0.28:.2f}"/>')
    out.append(f'<g fill="#ffffff">{"".join(cells)}</g>')
    # chain of reasoning steps
    xs = [70 + k * 92 for k in range(6)]
    y0 = 236
    chain = []
    for k, x in enumerate(xs):
        if k:
            chain.append(f'<path d="M{xs[k-1] + 34} {y0} L{x - 34} {y0}" stroke="#ffffff" stroke-opacity=".6" stroke-width="2"/>')
            chain.append(f'<path d="M{x - 40} {y0 - 5} L{x - 33} {y0} L{x - 40} {y0 + 5}" fill="none" stroke="#ffffff" stroke-opacity=".6" stroke-width="2"/>')
    for k, x in enumerate(xs):
        flagged = k == 4
        fill = "#f4b860" if flagged else "#ffffff"
        chain.append(f'<rect x="{x - 32}" y="{y0 - 20}" width="64" height="40" rx="10" fill="{fill}" fill-opacity="{1 if flagged else .92}"/>')
        for r in range(2):
            wv = 38 - 12 * r - (k % 3) * 4
            chain.append(f'<rect x="{x - 22}" y="{y0 - 9 + r * 11}" width="{wv}" height="5" rx="2.5" fill="#2a2150" opacity="{.5 - .15 * r:.2f}"/>')
    out.append("".join(chain))
    # lens with an enlarged neuron grid inside (interpretability)
    inner = []
    for i in range(7):
        for j in range(7):
            v = rng.random()
            col = "#f4b860" if v > 0.82 else "#ffffff"
            op = 0.9 if v > 0.82 else 0.15 + 0.35 * v
            inner.append(f'<circle cx="{392 + i * 20}" cy="{116 + j * 20}" r="5.5" fill="{col}" opacity="{op:.2f}"/>')
    out.append(f'<circle cx="452" cy="176" r="70" fill="#1d173b" fill-opacity=".72"/>')
    out.append(f'<g clip-path="url(#lens)">{"".join(inner)}</g>')
    out.append('<circle cx="452" cy="176" r="70" fill="none" stroke="#ffffff" stroke-width="6"/>')
    out.append('<path d="M402 226 L360 268" stroke="#ffffff" stroke-width="12" stroke-linecap="round"/>')
    # shield, top-left
    out.append('<g transform="translate(70 52)" fill="none" stroke="#ffffff" stroke-width="4" stroke-linejoin="round">'
               '<path d="M40 0 L78 14 V48 C78 76 60 92 40 102 C20 92 2 76 2 48 V14 Z" fill="#ffffff" fill-opacity=".12"/>'
               '<path d="M24 50 L36 62 L58 38" stroke-linecap="round"/></g>')
    return svg("".join(out), defs)


# ---------- 3. AI for physical systems: FE mesh coloured by a simulated field ----------
def physics():
    defs = ('<linearGradient id="gc" x1="0" y1="0" x2="1" y2="1">'
            '<stop offset="0" stop-color="#0d4650"/><stop offset="1" stop-color="#1f7f7a"/></linearGradient>')
    pts = []
    # refinement near a feature
    fx, fy = 400, 190
    while len(pts) < 330:
        x, y = rng.random() * W, rng.random() * H
        d = math.hypot(x - fx, y - fy)
        if rng.random() < 0.28 + 0.72 * math.exp(-(d / 120) ** 2):
            pts.append((x, y))
    for x in np.linspace(0, W, 15):
        pts += [(x, 0), (x, H)]
    for y in np.linspace(0, H, 10)[1:-1]:
        pts += [(0, y), (W, y)]
    P = np.array(pts)
    tri = Delaunay(P)

    def field(x, y):
        u = math.exp(-((x - fx) ** 2 + (y - fy) ** 2) / (2 * 95 ** 2))
        u += 0.35 * math.sin(x / 70) * math.cos(y / 55)
        u += 0.25 * math.exp(-((x - 150) ** 2 + (y - 300) ** 2) / (2 * 80 ** 2))
        return u

    stops = [(0.0, (13, 70, 80)), (0.45, (31, 127, 122)), (0.75, (110, 196, 170)), (1.0, (245, 222, 140))]

    def cmap(t):
        t = min(max(t, 0), 1)
        for (a, ca), (b, cb) in zip(stops, stops[1:]):
            if t <= b:
                s = (t - a) / (b - a)
                return "#%02x%02x%02x" % tuple(int(ca[i] + s * (cb[i] - ca[i])) for i in range(3))
        return "#%02x%02x%02x" % stops[-1][1]

    vals = [field(*P[s].mean(axis=0)) for s in tri.simplices]
    lo, hi = min(vals), max(vals)
    polys = []
    for s, v in zip(tri.simplices, vals):
        (x1, y1), (x2, y2), (x3, y3) = P[s]
        polys.append(f'<path d="M{f(x1)} {f(y1)}L{f(x2)} {f(y2)}L{f(x3)} {f(y3)}Z" fill="{cmap((v - lo) / (hi - lo))}"/>')
    out = [f'<rect width="{W}" height="{H}" fill="url(#gc)"/>',
           f'<g stroke="#ffffff" stroke-opacity=".28" stroke-width=".7" stroke-linejoin="round">{"".join(polys)}</g>']
    # streamline-like curves on top
    curves = []
    for k in range(5):
        y = 60 + k * 70
        curves.append(f'<path d="M-10 {y} C160 {y - 50} 300 {y + 60} 650 {y - 20}" />')
    out.append(f'<g fill="none" stroke="#ffffff" stroke-opacity=".35" stroke-width="2">{"".join(curves)}</g>')
    return svg("".join(out), defs)


# ---------- 4. Materials discovery: grain microstructure + crystal unit cell ----------
def materials():
    seeds = rng.random((70, 2)) * [W, H]
    mirrored = np.vstack([seeds,
                          np.c_[-seeds[:, 0], seeds[:, 1]], np.c_[2 * W - seeds[:, 0], seeds[:, 1]],
                          np.c_[seeds[:, 0], -seeds[:, 1]], np.c_[seeds[:, 0], 2 * H - seeds[:, 1]]])
    vor = Voronoi(mirrored)
    palette = ["#e9b384", "#d98b5f", "#f1d3a1", "#c96f4a", "#e7c27d", "#b8603e", "#f3e2bf", "#dca06d", "#a8553a"]
    polys = []
    for i in range(len(seeds)):
        region = vor.regions[vor.point_region[i]]
        if -1 in region or not region:
            continue
        v = vor.vertices[region]
        d = "M" + "L".join(f"{f(x)} {f(y)}" for x, y in v) + "Z"
        polys.append(f'<path d="{d}" fill="{palette[rng.integers(len(palette))]}"/>')
    out = [f'<rect width="{W}" height="{H}" fill="#e7c27d"/>',
           f'<g stroke="#5a2e1c" stroke-width="2.2" stroke-linejoin="round" stroke-opacity=".75">{"".join(polys)}</g>']
    # unit cell card on top
    cx, cy, s = 470, 200, 70
    def iso(x, y, z):
        return (cx + (x - y) * s * 0.87, cy + (x + y) * s * 0.5 - z * s)
    corners = [(x, y, z) for x in (0, 1) for y in (0, 1) for z in (0, 1)]
    cube_edges = [(a, b) for a in corners for b in corners if sum(abs(a[i] - b[i]) for i in range(3)) == 1 and a < b]
    atoms = corners + [(.5, .5, 0), (.5, .5, 1), (.5, 0, .5), (.5, 1, .5), (0, .5, .5), (1, .5, .5)]
    ox, oy = iso(.5, .5, .5)
    out.append(f'<circle cx="{f(ox)}" cy="{f(oy)}" r="118" fill="#3b1f14" fill-opacity=".55"/>')
    lines = []
    for a, b in cube_edges:
        (x1, y1), (x2, y2) = iso(*a), iso(*b)
        lines.append(f'<line x1="{f(x1)}" y1="{f(y1)}" x2="{f(x2)}" y2="{f(y2)}"/>')
    out.append(f'<g stroke="#ffffff" stroke-opacity=".8" stroke-width="2.4">{"".join(lines)}</g>')
    for a in sorted(atoms, key=lambda p: p[0] + p[1] - p[2]):
        x, y = iso(*a)
        face = 0.5 in a
        out.append(f'<circle cx="{f(x)}" cy="{f(y)}" r="{12 if face else 10}" fill="{"#ffe9c2" if face else "#ffffff"}" stroke="#5a2e1c" stroke-width="1.5"/>')
    return svg("".join(out))


art = {"agents": agents(), "alignment": alignment(), "physics": physics(), "materials": materials()}
json.dump(art, open(sys.argv[1], "w"))
print({k: len(v) for k, v in art.items()})
